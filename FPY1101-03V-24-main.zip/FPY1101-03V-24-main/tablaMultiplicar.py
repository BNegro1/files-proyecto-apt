num = int(input("Ingrese un número a multiplicar: "))

if num > 0:
    print(num,"* 1 = \t",num*1)
    print(num,"* 2 = \t",num*2)
    print(num,"* 3 = \t",num*3)
    print(num,"* 4 = \t",num*4)
    print(num,"* 5 = \t",num*5)
    print(num,"* 6 = \t",num*6)
    print(num,"* 7 = \t",num*7)
    print(num,"* 8 = \t",num*8)
    print(num,"* 9 = \t",num*9)
    print(num,"* 10 = \t",num*10)

else:
    print("Número es menor que cero")