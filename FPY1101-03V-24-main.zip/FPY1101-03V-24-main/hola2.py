print("Hola mundo")
