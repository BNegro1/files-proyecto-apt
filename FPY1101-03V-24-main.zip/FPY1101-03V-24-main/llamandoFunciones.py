import funciones as fn

actual = int(input("Ingrese año Actual: "))
aNac = int(input("Ingrese año Nacimento: "))
fn.calcularEdad(actual,aNac)


