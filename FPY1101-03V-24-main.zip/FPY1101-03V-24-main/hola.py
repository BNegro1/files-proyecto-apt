print("Hola mundo")
nombre = input("Ingrese su nombre: ")
print("Su nombre es: ",nombre)
num1 = int(input("Ingrese un numero "))
num2 = int(input("Ingrese otro numero "))
suma = num1 + num2
print("la suma de ",num1,"+",num2," es ",suma)
