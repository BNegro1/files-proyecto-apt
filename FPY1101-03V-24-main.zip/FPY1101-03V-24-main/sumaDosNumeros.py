num1 = int(input("Ingrese un número: "))
num2 = int(input("Ingrese otro número: "))

if num1 >0 and num2 >0 :
    suma = num1 + num2
    print(num1," + ",num2," = ",suma)
else:
    print("Los números deben ser positivos")