test = "hola123"
test2 = "2"

print(type(test))
print(test.isalnum())
print(test2.isalnum())