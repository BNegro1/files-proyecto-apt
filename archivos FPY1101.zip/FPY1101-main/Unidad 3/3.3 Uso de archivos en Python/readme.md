# 3.3 Uso de Archivos en Python

## leyendo_json_mio.py 
Ejercicio en donde calculo directamente metricas de los usuarios desde un archivo JSON.

## creacion_csv_mio, cracion_csv_profe , creando_csv_basico

Ejercicios básicos en donde se crean CSV a traves de distintas fuentes (desde un json, csv, objeto en python)


## Dir repasos
Repasos generales

## Dir clase dd-mm
Ejercicios que corresponden al día de la clase

## Dir ayudantia
Ejercicios realizados en las ayudantias


## *.csv
Archivos generados por los programas, los dejé para verlos como referencia.
