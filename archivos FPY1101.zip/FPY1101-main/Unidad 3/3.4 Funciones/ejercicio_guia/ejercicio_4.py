import funciones_app_ej4 as fn

lista_numeros = [3,2,3]

print(fn.calculadora_loca("suma_factorial",lista_numeros))