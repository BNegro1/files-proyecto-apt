# Repasos examen
Repasos para el examen de Fundamentos de Programación
