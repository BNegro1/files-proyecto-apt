# Ejercicio 1
Repaso de creacion de funciones y analisis de datos en general (min,max,prom).
## app.py
Ejecuta la funcion menu.

## menu.py
Aca esta la lógica del menu y usa las funciones importadas desde funciones.py

## funciones.py.
Aca esta la lógica de asignar creditos , analisis de datos y de generar el reporte en un csv.

## reporte_creditos.csv
CSV que genera la aplicación con los datos requeridos.