# Ejercicios Python Sección FPY1101 Duoc UC Viña del Mar

Ordenados por unidad y subunidad. Contiene los problemas , desarrollos mios, correcciones y repasos creados por mi durante sesiones de estudio.