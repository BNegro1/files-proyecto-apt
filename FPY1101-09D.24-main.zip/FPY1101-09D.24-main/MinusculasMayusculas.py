nombre = input("Ingrese nombre: ").lower()
print(nombre)

nombre = input("Ingrese nombre: ").upper()
print(nombre)