num = int(input("Ingrese número a multiplicar: "))

if num > 0 :
    print(num, "x1 =\t",num*1)
    print(num, "x2 =\t",num*2)
    print(num, "x3 =\t",num*3)
    print(num, "x4 =\t",num*4)
    print(num, "x5 =\t",num*5)
    print(num, "x6 =\t",num*6)
    print(num, "x7 =\t",num*7)
    print(num, "x8 =\t",num*8)
    print(num, "x9 =\t",num*9)
    print(num, "x10 =\t",num*10)
else:
    print("el número debe ser mayor a cero")