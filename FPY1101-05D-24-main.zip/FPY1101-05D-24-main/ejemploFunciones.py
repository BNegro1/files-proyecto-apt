import funciones as fn

## como llamamos a las funciones

fn.saludo()
print(fn.saludo2())
fn.sumar(3,4)
suma = fn.sumar2(5,6)
print(suma)

