
num1 = int(input("Ingrese un numero 1: "))
num2 = int(input("Ingrese un numero 2: "))
num3 = int(input("Ingrese un numero 3: "))
suma = num1 + num2 + num3
promedio = suma/3

print("El promedio de ",num1,",",num2,",",num3," es: ",promedio)

