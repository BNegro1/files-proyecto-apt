user = input("Ingresar el usuario: ")
passw = input("Ingrese contraseña: ")

if user == "pedro" and passw == "1234":
    print("Usuario conectado")
else:
    if user == "angel" and passw=="a4s1":
        print("usuario conectado")
    else:
        print("usuarios desconocidos")

