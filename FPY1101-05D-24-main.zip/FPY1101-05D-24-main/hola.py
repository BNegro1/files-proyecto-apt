print("Hola mundo") # escribir
print("Mi nombre es Profe Hernán")
# comentario de linea
print("********")
print("Ingrese su nombre: ")
nombre = input() # leer input()--> string o caracteres
print("Hola, ",nombre," bienvenido")
print("Cual es su edad:")
edad = input() # numero ---> int(input()) INTEGER , float(input()) --> DECIMALES
print("Su edad es :",edad)

num1 = int(input("Ingrese un numero 1: "))
num2 = int(input("Ingrese un numero 2: "))
suma = num1 + num2
print("La suma es: ", suma)