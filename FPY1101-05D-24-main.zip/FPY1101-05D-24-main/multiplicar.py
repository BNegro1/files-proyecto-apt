'''
Ejercicio 1:
Ingrese por teclado un número positivo y muestre su tabla de
multiplicar (considere que la tabla sea de 1 a 10).


'''