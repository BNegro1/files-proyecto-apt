# for ---> para

for num in range(3):
    print(num)

## tabla multiplicar del 1 al 10 de cualquier número 
# num = int(input("Ingrese el número: "))

# for i in range(1,11):
#     multi = num*i
#     print(num,"x",i,"=",multi)

## ciclo mientras ---> while
'''
cont = 0
while cont < 4:
    cont = cont + 1
    print("hola")

'''
## tabla multiplicar del 1 al 10 de cualquier número con mientras
'''num = int(input("Ingrese un número: "))

cont = 0
while cont < 10:
    cont = cont + 1
    multi = num * cont
    print(num,"x",cont,"=",multi)

'''
## ciclo repetir ---> while True 

# while True:
#     try:
#         print("   MENU  ")
#         print("*********")
#         print("1. Opcion 1")
#         print("2. Opcion 2")
#         print("3. Salir")
#         opc = int(input("Ingrese su opcion: "))
#         if opc >0 and opc <4:
#             if opc == 1:
#                 print("Aca esta el bloque de la opción 1")
#             else:
#                 if opc == 2:
#                     print("Aca esta el bloque de la opción 2")
#                 else:
#                     if opc == 3:
#                         break
#         else:
#             print("La opcion debe estar entre 1 y 3")
#     except:
#         print("Debe ser numero la opcion")
    
