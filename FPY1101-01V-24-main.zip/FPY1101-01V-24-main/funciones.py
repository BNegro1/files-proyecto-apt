import defFunciones as fn

#llamando funciones
fn.saludo()
fn.saludoNombre("JUACO")
fn.saludoNombre("VANIA")

suma = fn.suma()
print(suma)
num1 = int(input("Ingrese número 1: "))
num2 = int(input("Ingrese número 2: "))
print(fn.suma2(num1,num2))

