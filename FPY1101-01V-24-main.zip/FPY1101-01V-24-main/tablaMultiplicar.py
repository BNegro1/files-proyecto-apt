num = int(input("Ingrese numero para multiplicar: "))

if num > 0 :
    print(num," x 1 =\t",num*1)
    print(num," x 2 =\t",num*2)
    print(num," x 3 =\t",num*3)
    print(num," x 4 =\t",num*4)
    print(num," x 5 =\t",num*5)
    print(num," x 6 =\t",num*6)
    print(num," x 7 =\t",num*7)
    print(num," x 8 =\t",num*8)
    print(num," x 9 =\t",num*9)
    print(num," x 10 =\t",num*10)

else:
    print("debe ser positivo el número")