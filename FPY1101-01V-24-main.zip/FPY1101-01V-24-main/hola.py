print("hola mundo")
print("Mi primer programa")
print("Ingrese su nombre")
#print() # comentario de linea 
nombre = input() # leer nombre

num1 = input("Ingrese numero 1: ")
num1Entero = int(num1)
num2 = float(input("Ingrese numero 2: "))
suma = num1Entero + num2
print("La suma de ",num1," + ",num2," es ",suma)

palabra = "hola"
decimal = 3.9
entero = 30
verdad = False # o True Boolean

##calcular edad
print("Calculo de edad")
añoActual = int(input("Ingrese año Actual: "))
añoNac = int(input("Ingrese año Nacimiento: "))
edad = añoActual - añoNac
print("Su edad es: ",edad," app")

print("Probando GIT")
