usuario1 = "pedro"
usuario2 = "angel"
pass1 = "1234"
pass2 ="a4s1"

user = input("Ingrese usuario: ")
password  = input("Ingrese clave: ")

if user == usuario1 and password == pass1:
    print("Bienvenido ", user)
else:
    if user == usuario2 and password == pass2:
        print("Bienvenido ", user)
    else:
        print("Usuario no válido")
    


 